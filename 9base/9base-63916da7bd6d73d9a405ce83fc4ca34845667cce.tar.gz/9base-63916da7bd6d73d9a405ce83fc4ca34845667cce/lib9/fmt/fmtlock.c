/* Copyright (c) 2002-2006 Lucent Technologies; see LICENSE */
#include <stdarg.h>
#include "plan9.h"
#include "fmt.h"
#include "fmtdef.h"

void
__fmtlock(void)
{
}

void
__fmtunlock(void)
{
}
