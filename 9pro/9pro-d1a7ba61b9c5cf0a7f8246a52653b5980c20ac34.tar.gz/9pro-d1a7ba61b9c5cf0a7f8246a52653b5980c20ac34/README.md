# 9pro

Plan9-related tools for Unix-like operating systems.

 * 9pex - share a directory over stdin/stdout, can be used with socat/inetd
 * 9gc  - a very simple stdin/stdout 9gridchan client

This is all _WIP_ still.  9pex is working in read-only mode so far but
lacks proper auth, async IO, some more error control etc.

To build static binaries with musl:

```
CC=musl-gcc CFLAGS="-Os -s -g0 -static" ./build.sh
```

# Why

We can do better.

# Notes/todo

 * 9pex: to allow "escaping the root" by following symlinks you have to pass `-e` option
 * 9pex: chrooting with musl makes `realpath` not work as it requires /proc to be mounted, get rid of `realpath`?
 * 9gc: you can run it in termux on Android like so: `rlwrap -a'XXXXXXwth' -s 0 -t dumb 9gc -e NICKNAME`
