# c9

Low level 9p client and server.

## Examples

Until I have time to write a minimal example you could take a look at 
https://git.sr.ht/~ft/9pro/blob/master/9pex.c
