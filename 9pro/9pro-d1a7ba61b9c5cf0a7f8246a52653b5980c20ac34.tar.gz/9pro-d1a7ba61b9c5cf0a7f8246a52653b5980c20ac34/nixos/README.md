# Read-only 9pex in NixOS

```
sudo mkdir -p /etc/nixos/pkgs
sudo cp ninepex.nix /etc/nixos/pkgs/
```

And change `/etc/nixos/configuration.nix`:

```
{ config, pkgs, ... }:

let
  ninepex = pkgs.callPackage ./pkgs/ninepex.nix {};
in
{

.................

  services.xinetd = {
    enable = true;
    services = [
      {
        name = "9pfs";
        port = 564;
        user = "none";
        server = "${ninepex}/bin/9pex";
        serverArgs = "/home/9";
        flags = "KEEPALIVE REUSE";
        extraConfig = ''
          instances = UNLIMITED
        '';
      }
    ];
  };

.................

  users.users.none = {
    isNormalUser = false;
    isSystemUser = false;                                                                                              
    createHome = true;
    home = "/home/9";
    shell = "${pkgs.shadow}/bin/nologin";
  };

```

Files go to `/home/9`. With `rsync` it can be done as so:

```
rsync -iCaR \
        --exclude='.git*' \
        --exclude='*.out' \
        --exclude='*.[0125678vqki]' \
        --exclude='[0125678vqki].*' \
        --delete-excluded --delete \
        --chown none:nogroup \
	dir1 dir2 dir3 \
        root@host:/home/9/
```
