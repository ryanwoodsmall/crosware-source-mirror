#!/bin/sh
git subtree pull --prefix c9 git@git.sr.ht:~ft/c9 master --squash
