/* getservhost.h -- Description of getservhost.c */

/* Copyright (C) 1988, 1990, 1992 Free Software Foundation, Inc.

   This file is part of GNU Finger.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */

#if !defined (_GETSERVHOST_H_)
#define _GETSERVHOST_H_

/* Return a new string which is the name of the local GNU Finger server
   host.  If this cannot be determined, return a NULL pointer instead.
   Single argument ERROR_STREAM is a stream to print errors to; a NULL
   value for this argument means print no errors. */
char *getservhost ();

#endif /* _GETSERVHOST_H_ */
