#ifndef HEADER_UnsupportedProcessField
#define HEADER_UnsupportedProcessField
/*
htop - unsupported/ProcessField.h
(C) 2020 htop dev team
Released under the GNU GPLv2+, see the COPYING file
in the source distribution for its full text.
*/


#define PLATFORM_PROCESS_FIELDS  \
   // End of list


#endif /* HEADER_UnsupportedProcessField */
