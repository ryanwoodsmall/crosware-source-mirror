/* source: xio-shell.h */
/* Copyright Gerhard Rieger and contributors (see file CHANGES) */
/* Published under the GNU General Public License V.2, see file COPYING */

#ifndef __xio_shell_h_included
#define __xio_shell_h_included 1

extern const struct addrdesc xioaddr_shell;

extern const struct optdesc opt_shell;

#endif /* !defined(__xio_shell_h_included) */
