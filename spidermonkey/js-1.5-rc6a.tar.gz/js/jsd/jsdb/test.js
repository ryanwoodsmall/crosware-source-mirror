load('objects.js')
