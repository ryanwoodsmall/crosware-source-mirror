/*
 *   stunnel       TLS offloading and load-balancing proxy
 *   Copyright (C) 1998-2026 Michal Trojnara <Michal.Trojnara@stunnel.org>
 *
 *   This program is free software; you can redistribute it and/or modify it
 *   under the terms of the GNU General Public License as published by the
 *   Free Software Foundation; either version 2 of the License, or (at your
 *   option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *   See the GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License along
 *   with this program; if not, see <http://www.gnu.org/licenses>.
 *
 *   Linking stunnel statically or dynamically with other modules is making
 *   a combined work based on stunnel. Thus, the terms and conditions of
 *   the GNU General Public License cover the whole combination.
 *
 *   In addition, as a special exception, the copyright holder of stunnel
 *   gives you permission to combine stunnel with free software programs or
 *   libraries that are released under the GNU LGPL and with code included
 *   in the standard release of OpenSSL under the OpenSSL License (or
 *   modified versions of such code, with unchanged license). You may copy
 *   and distribute such a system following the terms of the GNU GPL for
 *   stunnel and the licenses of the other code concerned.
 *
 *   Note that people who make modified versions of stunnel are not obligated
 *   to grant this special exception for their modified versions; it is their
 *   choice whether to do so. The GNU General Public License gives permission
 *   to release a modified version without this exception; this exception
 *   also makes it possible to release a modified version which carries
 *   forward this exception.
 */

/* POSIX signal APIs define special handler values through pointer casts. */
/* cppcheck-suppress-file misra-c2012-11.6 */

#include "prototypes.h"

NOEXPORT int main_unix(int argc, char *argv[]);
#if !defined(__vms) && !defined(USE_OS2)
NOEXPORT int daemonize(int fd);
NOEXPORT int create_pid(void);
NOEXPORT void delete_pid(void);
#endif
#ifndef USE_OS2
NOEXPORT void signal_handler(int sig);
NOEXPORT int signal_set(int sig, void (*handler)(int));
NOEXPORT int signal_set_if_not_ignored(int sig);
#endif

int main(int argc, char* argv[]) { /* execution begins here 8-) */
    int retval;

#ifdef M_MMAP_THRESHOLD
    (void)mallopt(M_MMAP_THRESHOLD, 4096);
#endif
    retval=stunnel_init();
    if(retval)
        return retval;
    retval=main_unix(argc, argv);
    main_cleanup();
    return retval;
}

NOEXPORT int main_unix(int argc, char* argv[]) {
    int configure_status;

#if !defined(__vms) && !defined(USE_OS2)
    int fd;

    fd=open("/dev/null", O_RDWR); /* open /dev/null before chroot */
    if(fd==INVALID_SOCKET)
        fatal("Could not open /dev/null");
#endif
    main_init();
    configure_status=main_configure(argc>1 ? argv[1] : NULL,
        argc>2 ? argv[2] : NULL);
    switch(configure_status) {
    case 1: /* error -> exit with 1 to indicate error */
        (void)close(fd);
        return 1;
    case 2: /* information printed -> exit with 0 to indicate success */
        (void)close(fd);
        return 0;
    }
    if(service_options.next) { /* there are service sections -> daemon mode */
#if !defined(__vms) && !defined(USE_OS2)
        if(daemonize(fd)) {
            (void)close(fd);
            return 1;
        }
        (void)close(fd);
        /* create_pid() must be called after drop_privileges()
         * or it won't be possible to remove the file on exit */
        /* create_pid() must be called after daemonize()
         * since the final pid is not known beforehand */
        if(create_pid())
            return 1;
#endif
#ifndef USE_OS2
        {
            int signal_errors;

            /* handle dead children */
            signal_errors=signal_set(SIGCHLD, signal_handler);
            /* configuration reload */
            signal_errors+=signal_set(SIGHUP, signal_handler);
            /* log reopen */
            signal_errors+=signal_set(SIGUSR1, signal_handler);
            /* connections */
            signal_errors+=signal_set(SIGUSR2, signal_handler);
            /* ignore broken pipe */
            signal_errors+=signal_set(SIGPIPE, SIG_IGN);
            signal_errors+=signal_set_if_not_ignored(SIGTERM); /* fatal */
            signal_errors+=signal_set_if_not_ignored(SIGQUIT); /* fatal */
            signal_errors+=signal_set_if_not_ignored(SIGINT); /* fatal */
            if(signal_errors) {
#if !defined(__vms)
                delete_pid();
#endif
                return 1;
            }
        }
#endif
#ifdef USE_FORK
        setpgid(0, 0); /* create a new process group if needed */
#endif
        daemon_loop();
#ifdef USE_FORK
        s_log(LOG_NOTICE, "Terminating service processes");
        (void)signal(SIGCHLD, SIG_IGN);
        (void)signal(SIGTERM, SIG_IGN);
        kill(0, SIGTERM); /* kill the whole process group */
        while(wait(NULL)!=-1)
            ;
        s_log(LOG_NOTICE, "Service processes terminated");
#endif
#if !defined(__vms) && !defined(USE_OS2)
        delete_pid();
#endif /* standard Unix */
    } else { /* inetd mode */
        CLI *c;
#if !defined(__vms) && !defined(USE_OS2)
        (void)close(fd);
#endif /* standard Unix */
#ifndef USE_OS2
        {
            int signal_errors;

            /* ignore dead children */
            signal_errors=signal_set(SIGCHLD, SIG_IGN);
            /* ignore broken pipe */
            signal_errors+=signal_set(SIGPIPE, SIG_IGN);
            if(signal_errors)
                return 1;
        }
#endif
        set_nonblock(0, 1); /* stdin */
        set_nonblock(1, 1); /* stdout */
        c=alloc_client(&service_options);
        c->local_rfd.fd=0;
        c->local_wfd.fd=1;
        (void)tls_alloc(c, ui_tls, NULL);
        (void)service_up_ref(&service_options);
        client_main(c);
        service_free(c->opt);
        free_client(c);
    }
    return 0;
}

#ifndef USE_OS2
NOEXPORT void signal_handler(int sig) {
    int saved_errno;

    saved_errno=errno;
    signal_post((uint8_t)sig);
    /* There is no async-signal-safe recovery if reinstallation fails. */
    (void)signal(sig, signal_handler);
    errno=saved_errno;
}

NOEXPORT int signal_set(int sig, void (*handler)(int)) {
    void (*previous)(int);

    previous=signal(sig, handler);
    if(previous==SIG_ERR) {
        ioerror("signal");
        return 1;
    }
    return 0;
}

NOEXPORT int signal_set_if_not_ignored(int sig) {
    void (*previous)(int);

    previous=signal(sig, SIG_IGN);
    if(previous==SIG_ERR) {
        ioerror("signal");
        return 1;
    }
    if(previous!=SIG_IGN)
        return signal_set(sig, signal_handler);
    return 0;
}
#endif

#if !defined(__vms) && !defined(USE_OS2)

NOEXPORT int daemonize(int fd) { /* go to background */
    if(global_options.option.foreground)
        return 0;
    {
        int duplicate_result;

        duplicate_result=dup2(fd, 0);
        if(duplicate_result<0) {
            ioerror("dup2");
            return 1;
        }
        duplicate_result=dup2(fd, 1);
        if(duplicate_result<0) {
            ioerror("dup2");
            return 1;
        }
        duplicate_result=dup2(fd, 2);
        if(duplicate_result<0) {
            ioerror("dup2");
            return 1;
        }
    }
#if defined(HAVE_DAEMON) && !defined(__BEOS__)
    /* set noclose option when calling daemon() function,
     * so it does not require /dev/null device in the chrooted directory */
    if(daemon(0, 1)==-1) {
        ioerror("daemon");
        return 1;
    }
#else
    chdir("/");
    switch(fork()) {
    case -1:    /* fork failed */
        ioerror("fork");
        return 1;
    case 0:     /* child */
        break;
    default:    /* parent */
        exit(0);
    }
#endif
    (void)tls_alloc(NULL, ui_tls, "main"); /* reuse thread-local storage */
#ifdef HAVE_SETSID
    (void)setsid(); /* ignore the error */
#endif
    return 0;
}

NOEXPORT int create_pid(void) {
    int pf;
    char *pid;

    if(!global_options.pidfile) {
        s_log(LOG_DEBUG, "No pid file being created");
        return 0;
    }

    /* silently remove the old pid file */
    (void)unlink(global_options.pidfile);

    /* create a new pid file */
    /* POSIX permission bits are conventionally and most clearly octal. */
    /* cppcheck-suppress misra-c2012-7.1 */
    pf=open(global_options.pidfile, O_WRONLY|O_CREAT|O_TRUNC|O_EXCL, 0644);
    if(pf==-1) {
        s_log(LOG_ERR, "Cannot create pid file %s", global_options.pidfile);
        ioerror("create");
        return 1;
    }
    pid=str_printf("%lu\n", (unsigned long)getpid());
    if(write(pf, pid, strlen(pid))<(int)strlen(pid)) {
        s_log(LOG_ERR, "Cannot write pid file %s", global_options.pidfile);
        ioerror("write");
        (void)close(pf);
        return 1;
    }
    str_free(pid);
    (void)close(pf);
    s_log(LOG_DEBUG, "Created pid file %s", global_options.pidfile);
    return 0;
}

NOEXPORT void delete_pid(void) {
    if(global_options.pidfile) {
        if(unlink(global_options.pidfile)<0)
            ioerror(global_options.pidfile); /* not critical */
        else
            s_log(LOG_DEBUG, "Removed pid file %s", global_options.pidfile);
    } else {
        s_log(LOG_DEBUG, "No pid file to remove");
    }
}

#endif /* standard Unix */

/**************************************** options callbacks */

void ui_config_reloaded(void) {
    /* no action */
}

#ifdef ICON_IMAGE

ICON_IMAGE load_icon_default(ICON_TYPE icon) {
    (void)icon; /* squash the unused parameter warning */
    return (ICON_IMAGE)0;
}

ICON_IMAGE load_icon_file(const char *file) {
    (void)file; /* squash the unused parameter warning */
    return (ICON_IMAGE)0;
}

#endif

/**************************************** client callbacks */

void ui_new_chain(const unsigned section_number) {
    (void)section_number; /* squash the unused parameter warning */
}

void ui_clients(const long num) {
    (void)num; /* squash the unused parameter warning */
}

/**************************************** s_log callbacks */

void ui_new_log(const char *line) {
    (void)fprintf(stderr, "%s\n", line);
}

/**************************************** ctx callbacks */

int ui_passwd_cb(char *buf, int size, int rwflag, void *userdata) {
    return PEM_def_callback(buf, size, rwflag, userdata);
}

#if !defined(OPENSSL_NO_ENGINE) || OPENSSL_VERSION_NUMBER>=0x10101000L

int (*ui_get_opener(void)) (UI *ui) {
    return UI_method_get_opener(UI_OpenSSL());
}

int (*ui_get_writer(void)) (UI *ui, UI_STRING *uis) {
    return UI_method_get_writer(UI_OpenSSL());
}

int (*ui_get_reader(void)) (UI *ui, UI_STRING *uis) {
    return UI_method_get_reader(UI_OpenSSL());
}

int (*ui_get_closer(void)) (UI *ui) {
    return UI_method_get_closer(UI_OpenSSL());
}

#endif /* !defined(OPENSSL_NO_ENGINE) || OPENSSL_VERSION_NUMBER>=0x10101000L */

/* end of ui_unix.c */
