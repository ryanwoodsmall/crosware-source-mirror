#ifndef VERSION_H_
#define VERSION_H_

#define PROGRAM_NAME "em"
#define PROGRAM_NAME_LONG "uEmacs/Pk"

#define	VERSION	"4.0.15"

/* Print the version string. */
void version(void);

#endif  /* VERSION_H_ */
