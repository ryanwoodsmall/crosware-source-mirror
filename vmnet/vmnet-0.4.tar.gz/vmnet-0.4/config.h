#define CONFIG_FILE "/etc/vmnet.conf"
#define IFCONFIG "/sbin/ifconfig"
