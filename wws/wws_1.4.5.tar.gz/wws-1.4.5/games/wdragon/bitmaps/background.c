#define background_width 16
#define background_height 16
static unsigned char background_bits[] = {
    2,  0,  0,  0, 64,  0,  0,  0,  0,  0,  0,  0,  0,  1,  0,  0,
    0, 32,  0,  0,  4,  0,  0,  0,128,  0,  0,  0,  0,  0,  0,  0,
    0,  2,  0,  0,  0, 64,  0,  0,  8,  0,  0,  0,  0,  0,  0,  0,
    0,  0,  0,  0,  0,  4,  0,  0,  0,128,  0,  0, 16,  0,  0,  0,
};
