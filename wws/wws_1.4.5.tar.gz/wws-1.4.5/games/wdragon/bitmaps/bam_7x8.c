#define bam_7x8_width 7
#define bam_7x8_height 8
static unsigned char bam_7x8_bits[] = {
    0,  0,  0,  0, 56,  0,  0,  0,108,  0,  0,  0, 40,  0,  0,  0,
   40,  0,  0,  0,108,  0,  0,  0, 56,  0,  0,  0,  0,  0,  0,  0,
};
