#define dot_7x8_width 7
#define dot_7x8_height 8
static unsigned char dot_7x8_bits[] = {
    0,  0,  0,  0, 84,  0,  0,  0, 56,  0,  0,  0,108,  0,  0,  0,
   56,  0,  0,  0, 84,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
};
