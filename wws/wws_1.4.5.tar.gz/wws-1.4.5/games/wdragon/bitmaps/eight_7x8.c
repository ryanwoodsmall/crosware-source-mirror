#define eight_7x8_width 7
#define eight_7x8_height 8
static unsigned char eight_7x8_bits[] = {
    0,  0,  0,  0, 56,  0,  0,  0,108,  0,  0,  0, 56,  0,  0,  0,
  108,  0,  0,  0,108,  0,  0,  0, 56,  0,  0,  0,  0,  0,  0,  0,
};
