#define five_7x8_width 7
#define five_7x8_height 8
static unsigned char five_7x8_bits[] = {
    0,  0,  0,  0,124,  0,  0,  0, 96,  0,  0,  0, 96,  0,  0,  0,
   24,  0,  0,  0, 76,  0,  0,  0, 56,  0,  0,  0,  0,  0,  0,  0,
};
