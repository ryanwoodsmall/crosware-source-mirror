#define four_10x12_width 10
#define four_10x12_height 12
static unsigned char four_10x12_bits[] = {
    0,  0,  0,  0,  3,  0,  0,  0,  7,  0,  0,  0, 15,  0,  0,  0,
   31,  0,  0,  0, 59,  0,  0,  0,127,128,  0,  0,127,128,  0,  0,
    3,  0,  0,  0,  3,  0,  0,  0,  3,  0,  0,  0,  0,  0,  0,  0,
};
