#define four_7x8_width 7
#define four_7x8_height 8
static unsigned char four_7x8_bits[] = {
    0,  0,  0,  0, 24,  0,  0,  0, 56,  0,  0,  0,104,  0,  0,  0,
  124,  0,  0,  0, 24,  0,  0,  0, 24,  0,  0,  0,  0,  0,  0,  0,
};
