#define one_7x8_width 7
#define one_7x8_height 8
static unsigned char one_7x8_bits[] = {
    0,  0,  0,  0, 24,  0,  0,  0, 56,  0,  0,  0, 24,  0,  0,  0,
   24,  0,  0,  0, 24,  0,  0,  0, 60,  0,  0,  0,  0,  0,  0,  0,
};
