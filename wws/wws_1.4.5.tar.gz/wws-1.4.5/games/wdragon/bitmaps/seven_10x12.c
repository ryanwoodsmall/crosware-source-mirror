#define seven_10x12_width 10
#define seven_10x12_height 12
static unsigned char seven_10x12_bits[] = {
    0,  0,  0,  0,127,128,  0,  0,127,128,  0,  0,  1,128,  0,  0,
    3,128,  0,  0,  7,  0,  0,  0, 14,  0,  0,  0, 28,  0,  0,  0,
   56,  0,  0,  0,112,  0,  0,  0, 96,  0,  0,  0,  0,  0,  0,  0,
};
