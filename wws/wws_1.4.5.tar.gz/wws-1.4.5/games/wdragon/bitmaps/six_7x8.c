#define six_7x8_width 7
#define six_7x8_height 8
static unsigned char six_7x8_bits[] = {
    0,  0,  0,  0, 56,  0,  0,  0,108,  0,  0,  0, 64,  0,  0,  0,
  120,  0,  0,  0,108,  0,  0,  0, 56,  0,  0,  0,  0,  0,  0,  0,
};
