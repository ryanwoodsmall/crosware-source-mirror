#define three_10x12_width 10
#define three_10x12_height 12
static unsigned char three_10x12_bits[] = {
    0,  0,  0,  0, 62,  0,  0,  0,127,  0,  0,  0, 99,  0,  0,  0,
    3,  0,  0,  0, 30,  0,  0,  0, 30,  0,  0,  0,  3,  0,  0,  0,
   99,  0,  0,  0,127,  0,  0,  0, 62,  0,  0,  0,  0,  0,  0,  0,
};
