#define two_7x8_width 7
#define two_7x8_height 8
static unsigned char two_7x8_bits[] = {
    0,  0,  0,  0, 56,  0,  0,  0,108,  0,  0,  0, 12,  0,  0,  0,
   24,  0,  0,  0, 48,  0,  0,  0,124,  0,  0,  0,  0,  0,  0,  0,
};
