/* Reversi game id for server connection */

#define REVERSI_ID	0x52455349			/* "RESI" (REverSI) */
