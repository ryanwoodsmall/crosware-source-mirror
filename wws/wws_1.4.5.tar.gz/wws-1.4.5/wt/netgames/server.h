/*
 * Networked, turn based, two player game framework.
 *
 * Include for server programs.
 *
 * (w) 1996 by Eero Tamminen
 */

#define GAME_SERVER
#include "game.h"
