/* dial widget include */

#define DialHalfCircle		0
#define DialFullCircle		1

extern widget_class_t *wt_dial_class;
